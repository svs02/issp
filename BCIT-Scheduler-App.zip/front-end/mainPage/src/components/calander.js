import React from "react";
import calender_img from "../calender.jpg"

const calender = () => {
    return (
        <div className="imgWrapper">
            <img className="fifth" src={calender_img} alt="calender"></img>
        </div>

    )
}


export default calender