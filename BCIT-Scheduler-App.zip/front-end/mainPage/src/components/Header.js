import React from "react";
const Header = () => {
    return (
        <div className="header-wraper">
            <div className="floor-selector">
                <span className="fifth">
                    Floor 5
                </span>
                <span className="sixth">
                    Floor 6
                </span>
            </div>
        </div>
    )

}

export default Header;