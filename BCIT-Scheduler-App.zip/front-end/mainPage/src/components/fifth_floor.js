import React from "react";
import fifth_floor_img from "../5th_floor.jpg"

const fifth_floor = () => {
    return (
        <div className="imgWrapper">
            <img className="fifth" src={fifth_floor_img} alt="fifth_floor"></img>
        </div>

    )
}


export default fifth_floor